$(document).ready(function () {
    $("#unos").keyup(function () {
        var value = $("#unos");
        value = value.val().toLowerCase();
        $("#tabla tr").filter(function () {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
        });
    });

    $("a").click(function (e) {
        var value = $(this)
        value = value.text().toLowerCase();
        $("#tabla tr").filter(function () {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
        });
    });

});

